jQuery(document).ready(function($) {
    // Add your custom JavaScript code here
});
