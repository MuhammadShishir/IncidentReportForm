<?php
/**
 * Plugin Name: Incident Report Form Elementor
 * Description: This plugin provides an Elementor widget for creating customizable incident report forms with various functionalities.
 * Version: 1.0.0
 * Author: MKS Entertainment & Technologies
 * Author URI: https://mkshishir.pages.dev
 * Text Domain: incident-report-form-elementor
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) exit;


class Incident_Report_Form_Elementor {
    
    public function __construct() {
                // Enqueue scripts and styles
       add_action('elementor/frontend/after_register_scripts', array($this, 'enqueue_incident_report_assets'));
 
       // Register the Elementor widget
       add_action('elementor/widgets/widgets_registered', array($this, 'register_incident_report_widget'));

       $this->enqueue_scripts();

        add_action('admin_post_submit_incident_report', array($this, 'submit_report'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    function enqueue_incident_report_assets() {
        // Enqueue your CSS and JS files here
        wp_enqueue_style('incident-report-form-elementor-style', plugin_dir_url(__FILE__) . '/assets/css/frontend-styles.css');
        wp_enqueue_script('incident-report-form-elementor-script', plugin_dir_url(__FILE__) . '/assets/js/frontend-scripts.js', array('jquery'), null, true);

    }

    // Register the Elementor widget
    function register_incident_report_widget() {
        // Include your widget class file and register the widget
        require_once(plugin_dir_path(__FILE__) . 'includes/class-incident-report-widget.php');

        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Incident_Report_Widget());
    }
    public function enqueue_scripts() {
        wp_enqueue_script('incident-report-frontend-scripts', plugin_dir_url(__FILE__) . '/assets/js/frontend-scripts.js', array('jquery'), null, true);
        wp_enqueue_style('incident-report-frontend-styles', plugin_dir_url(__FILE__) . '/assets/css/frontend-styles.css', array(), null);
    
        // Localize script with AJAX URL and other necessary data
        wp_localize_script('incident-report-frontend-scripts', 'incident_report_ajax_object', array('ajaxurl' => admin_url('admin-ajax.php')));
    }
    
    
    public function submit_report() {
        // Check nonce and permissions
        if ( ! isset( $_POST['submit_incident_report_nonce'] ) || ! wp_verify_nonce( $_POST['submit_incident_report_nonce'], 'submit_incident_report' ) ) {
            wp_die( 'Unauthorized access!' );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Access denied!' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'incident_reports';

        // Sanitize input data
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $message = sanitize_textarea_field($_POST['message']);
        $location = sanitize_text_field($_POST['location']);
        $latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : '';
        $longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : '';

        // Insert data into the database
        $wpdb->insert($table_name, array(
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'message' => $message,
            'location' => $location,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'submitted_at' => current_time('mysql'),
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ));

        // Redirect after form submission
        wp_redirect(home_url('/thank-you'));
        exit;
    }

    public function add_admin_menu() {
        add_menu_page(
            'Incident Reports',
            'Incident Reports',
            'manage_options',
            'incident-reports',
            array($this, 'render_incident_reports_page'),
            'dashicons-warning'
        );
    }

    public function render_incident_reports_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'incident_reports';
        $incident_reports = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

        echo '<div class="wrap">';
        echo '<h1>Incident Reports</h1>';
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Message</th><th>Location</th><th>Latitude</th><th>Longitude</th><th>Submitted At</th><th>IP Address</th></tr></thead>';
        echo '<tbody>';
        foreach ($incident_reports as $incident_report) {
            echo '<tr>';
            echo '<td>' . esc_html($incident_report['name']) . '</td>';
            echo '<td>' . esc_html($incident_report['email']) . '</td>';
            echo '<td>' . esc_html($incident_report['phone']) . '</td>';
            echo '<td>' . esc_html($incident_report['message']) . '</td>';
            echo '<td>' . esc_html($incident_report['location']) . '</td>';
            echo '<td>' . esc_html($incident_report['latitude']) . '</td>';
            echo '<td>' . esc_html($incident_report['longitude']) . '</td>';
            echo '<td>' . esc_html($incident_report['submitted_at']) . '</td>';
            echo '<td>' . esc_html($incident_report['ip_address']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    }
}

new Incident_Report_Form_Elementor();

